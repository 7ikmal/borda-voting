function getVotes(){return JSON.parse(localStorage.getItem("bordaVotes:v1")||"[]");}
function saveVote(ranking){
 let all=getVotes();
 all.push({voterId:Date.now(),timestamp:Date.now(),ranking});
 localStorage.setItem("bordaVotes:v1",JSON.stringify(all));
}
