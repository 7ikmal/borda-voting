function computeBordaScores(votes){
 let scores={};
 CANDIDATES.forEach(c=>scores[c]=0);
 votes.forEach(v=>{
   v.ranking.forEach((c,i)=>{
     scores[c]+=CANDIDATES.length-i;
   });
 });
 return scores;
}
