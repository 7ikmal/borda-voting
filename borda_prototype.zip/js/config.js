const ORG_NAME="Organisasi Demo";
const ORG_TYPE="OSIS";
const CANDIDATES=["Aulia","Bima","Citra","Davin"];
const SCORING="descending";
const ALLOW_TIES=false;
